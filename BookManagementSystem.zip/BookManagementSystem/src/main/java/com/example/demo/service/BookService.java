package com.example.demo.service;

import com.example.demo.exception.BookNotFoundException;
import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository repository;

    public List<Book> getAllBooks() {
        return repository.findAll();
    }

    public Optional<Book> getBookByIsbn(String isbn) {
        return Optional.ofNullable(repository.findById(isbn)
                .orElseThrow(() -> new BookNotFoundException("Book not found with ISBN: " + isbn)));
    }

    public Book addBook(Book book) {
        return repository.save(book);
    }

    public Book updateBook(String isbn, Book updatedBook) {
        Book existingBook = repository.findById(isbn)
                .orElseThrow(() -> new BookNotFoundException("Cannot update. Book not found with ISBN: " + isbn));
        
        updatedBook.setIsbn(isbn);
        return repository.save(updatedBook);
    }

    public void deleteBook(String isbn) {
        Book existingBook = repository.findById(isbn)
                .orElseThrow(() -> new BookNotFoundException("Cannot delete. Book not found with ISBN: " + isbn));

        repository.delete(existingBook);
    }
}

