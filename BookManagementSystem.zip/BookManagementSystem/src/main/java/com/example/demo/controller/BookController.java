package com.example.demo.controller;

import com.example.demo.dto.ApiResponse;
import com.example.demo.model.Book;
import com.example.demo.service.BookService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService service;

    @GetMapping
    public List<Book> getAllBooks() {
        return service.getAllBooks();
    }

    @GetMapping("/{isbn}")
    public ResponseEntity<Book> getBook(@PathVariable String isbn) {
        return service.getBookByIsbn(isbn)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ApiResponse> createBook(@Valid @RequestBody Book book) {
        service.addBook(book);
        return ResponseEntity.ok(new ApiResponse("Book added successfully"));
    }

    @PutMapping("/{isbn}")
    public ResponseEntity<ApiResponse> updateBook(@PathVariable String isbn, @Valid @RequestBody Book book) {
        service.updateBook(isbn, book);
        return ResponseEntity.ok(new ApiResponse("Book updated successfully"));
    }

    @DeleteMapping("/{isbn}")
    public ResponseEntity<ApiResponse> deleteBook(@PathVariable String isbn) {
        service.deleteBook(isbn);
        return ResponseEntity.ok(new ApiResponse("Book deleted successfully"));
    }
}


